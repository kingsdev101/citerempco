<div class="estep3">


            <div class="wrap-boxes">
            <div class="einfo-section">
        <div class="group-boxes">
            <p class="ap">Applicant</p>
            <p>Full Name : <span>Brian Orbino</span></p>
            <p>School Address: <span>123 Kasoy Isulan bambad</span></p>

            <p>Purpose of Loans: <span>To build a beeter place for everuyone</span></p>
        </div>
        <div class="group-boxes">
        <p class="pb-4"></p>
            <p>Date: <span>2020/11/23</span></p>
            <p>Application No: <span> 23</span> </p>
            <p>Net Take Home Pay: <span>30,300</span> </p>
            <p>Amount Loan Granted: <span>20,000</span></p>
        </div>
    </div>


            </div>
       <div class="eiregister">
        <p>I <span class="eregistspace">Brian Orbino Brian  </span> a registered bonafide member of a registered bonafide
            member of CENTRAL ISULAN TEACHERS, EMPLOYEE AND RETIREES MULTI - PURPOSE COOPERATIVE (CITEREMPCO) hereby
            apply for the Emergency Loan in the amount of <span class="eregistspace">30,3300 </span> I agree to abide
            and
            comply with the terms and condition sets forth below. <span class="eregistspace"> 30 days</span> Pay the
            monthly interest of three (3%) and pay for only for six
        </p>

        <p>I hereby pledge to: <span class="eiherespace"></span> </p>
        <p> Pay the monthly interest of three (3%) and pay for only for six (6) months, in installment or in full,
            hereby to pay to the CITEREMPCO Treasurer.
        </p>

    </div>
    <p class="enwitness">In witness whereof i here unto affix my signature this</p>

    <div class="esignature-areas">
        <div class="eap-br">
            <div class="eap-ab-box">
                
                <p></p>
                <div>Applicant / Barrower</div>
            </div>
        </div>
        <div class="loan-b">
            <div class="elbox">
                <p>Prepared By:

                </p>
                <div>
                    <p>ARCELY B. PILVERA </p>
                    <div>Loan Officer</div>
                </div>
            </div>
            <div class="elbox">
                <p>Checked By:</p>
                <div>
                    <p>EVELYN L. PERALTA </p>
                    <div>Book Keeper </div>
                </div>
            </div>
        </div>
        <div class="loan-b">
            <div class="elbox">
                <p>Recommending Approval:

                </p>
                <div>
                    <p>MARCELA M. LAGUMEN</p>
                    <div>Manager</div>
                </div>
            </div>
            <div class="elbox">
                <p>Approved By:</p>
                <div>
                    <p>BDO Chairman </p>
                    <div>Book Keeper </div>
                </div>
            </div>
        </div>

        <div class="loan-b">
            <div class="elbox">
            Disbursing officer:
            </div>
            <div class="elbox">

            </div>
        </div>


    </div>

            <div class="etrasurere">
                <div>
                <p>CORAZON G. NALANG</p>
                <div>Treasurer</div>
                </div>
            </div>
            <div class="einfo">
            <div class="circle-wrapper">

                
            </div>
            <div class="stepbutton">
                <button type="button" class="eprevbtn2">previous</button>
                <button type="submit" class="submit">submit</button>
            </div>
            </div>
        </div>
            <div class="stepbutton">

</div>