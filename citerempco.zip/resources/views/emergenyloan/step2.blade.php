<div class="estep2">

    <div class="epar">

        <p>
            I <input type="text" placeholder="name" class="ename"> a registered bonafide member of a registered bonafide
            member of  CENTRAL ISULAN TEACHERS, EMPLOYEE AND RETIREES MULTI - PURPOSE COOPERATIVE (CITEREMPCO) hereby apply for the Emergency Loan in the amount of <input type="text" placeholder="Amount" class="eamount"> <input type="text" placeholder="Php"
                class="ephp"> I agree to abide and comply with the terms and condition sets forth below. Pay the monthly
            interest of three (3%) and pay for only for six

        </p>
        <p>I hereby pledge to:</p>

        <p> Pay the monthly interest of three (3%) and pay for only for six (6) months, in installment or in full,
            hereby to pay to the CITEREMPCO Treasurer.
        </p>

        <p>In witness whereof i here unto affix my signature this <input type="date" class="edate"></p>

    </div>

    <div class="ap-br">
        <div class="ap-ab-box">
            <input type="text">
            <div>Applicant / Barrower</div>
        </div>
    </div>
    
    <div class="einfo">
            <div class="circle-wrapper">
                <div></div>
                <div class="active"></div>
                
            </div>
            <div class="stepbutton">
                <button type="button" class="eprevbtn1">previous</button>
                <button type="button" class="enextbtn2">next</button>
            </div>
        </div>


</div>