<div class="step4 p2">
    <div class="step4-wrapper">

        <p>
            For value received, I promised to pay the CENTRAL ISULAN TEACHERS, EMPLOYEES AND RETIREES
            MULTI
            -
            PURPOSE COOPERATIVE or order the sum of <input type="text" name="step4[sumof]" id="step4_sumof"
                class="form-control ins stp4in1">
            pesos<input type="text" name="step4[pesos]" id="step4_pesos" class="form-control ins stp4in2"> payable
            <input type="text" name="step4[payable]" id="step4_payable" class="form-control  ins stp4in3">in installment
            of <input type="text" name="step4[installment]" id="step4_installment" class="form-control">
            pesos<input type="text" name="step4[installmentpesos]" id="step4_installmentpesos"
                class="form-control ins stp4in4"> monthly until the
            full
            amount has been paid.</p>
        <p>

            In case dafault in payments as here in agreed, the entire balance of this note shall become
            immediately
            due to the payable at the option of the cooperative

        </p>
    </div>
    <div class="btns">
        <div class="dots">
            <div class=""></div>
            <div class=""></div>
            <div class=""></div>
            <div class="activates"></div>
        </div>
        <div>

            <button type="button" class="btn btn-default prev3">Previous</button>
            <button type="submit" class="btn btn-default submit1">Submit</button>
        </div>
    </div>
</div>