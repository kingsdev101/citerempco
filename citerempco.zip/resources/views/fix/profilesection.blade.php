<section class="profile-section">
    <div class="profileimage">
        <div class="image">
            <img src="{{asset('storage/project_mages/user.png')}}" alt="user">
        </div>
        <div class="">
            <p>John Ross B. Mariñas</p>
            <span>Member</span>
        </div>
    </div>

    <div class="requirements">
        Requirements
    </div>

    <div class="menu-list">
        <ul>

            <li> <a href="{{route('citerempco.loanapplication.form')}}">Application Form</a></li>
            <li><a href="{{route('citerempco.deedofassigment.index')}}"> Deed of Assignment</a></li>
            <li> <a href="{{route('citerempco.promissory.index')}}"> Promissory Note</a></li>
            <li><a href="{{route('citerempco.credit.index')}}"> Application for Credit</a></li>
            <li><a href="{{route('citerempco.certication.index')}}"> Certification </a></li>
            <li><a href="{{route('citerempco.creditlifeinsurance.index')}}"> Credit Life Insurance</a></li>
            <li><a href="{{route('citerempco.emergencyloan.index')}}"> Emergency Loan</a></li>
            <li><a href="{{route('citerempco.applicationfadds.index')}}"> Application Form for ADDS</a></li>
            <li><a href="{{route('citerempco.loanagreement.index')}}">Loan Application Agreement</a></li>
        </ul>
    </div>

</section>