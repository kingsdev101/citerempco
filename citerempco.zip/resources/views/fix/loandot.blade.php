<div class="dots">
    <div class="activates"></div>
    <div class=""></div>
    <div class=""></div>
    <div class=""></div>
</div>