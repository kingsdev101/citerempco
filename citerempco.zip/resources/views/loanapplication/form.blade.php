@extends('layouts.custome')

@section('content')
<div class="applicationform">
    @include('fix.profilesection')
<div class="applicationform-content">

   @include('form.loanapplicationform')

</div>
</div>
@endsection