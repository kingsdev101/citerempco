<div class="lstep4">


    <div class="par-bundle">
        <div class="par-section">

            <p>
                I hereby declare and agree that all statements and answers conatined her in are full complet and true in
                the
                event undergo a medical examination, my statements an representations there under shall take the place
                of
                the above questionaire for the purpose of the application. I understand that the insurance applied for
                will
                not become affective until this application is approved by the Insurance Company at its Home Office.
            </p>

            <p>
                I hereby further declare and agree that, while I am insured in accordance with the terms of the Group
                Credit
                Life Insurance Policy here in applied for this amount of insurance in force at the time of my death and
                not
                exceeding the maximun amount specified there in shall be applied as payment to reduce or extinguish my
                indeptedness to the CREDITOR/ASSURED <input type="text" name="step4[assured]"> and any excess of the amount of insurance over
                my indeptedness shall be
                paid to my beneficiary, pursuent to the cotract of insurance issued by the Insurer. The Philippine
                American
                Life and General Insurance Company.
            </p>
        </div>
        <div class="signeat-section">
            <p>Signed at: <input type="text" name="step4[signat]"> on this <input type="date" name="step4[date]"></p>
        </div>

        <div class="lwitness-signature-section">
            <div class="wrap-signature">
                <div><input type="text" name="step4[witness]"></div>
                <div class="llines">Witness</div>
            </div>
            <div class="wrap-signature">
                <div><input type="text" name="step4[debtor]"></div>
                <div class="llines">Signature of Debtor</div>
            </div>
        </div>
        <div class="stepinfo">
        <div class="circle-wrapper">
        <div></div>
                <div></div>
                <div></div>
                <div class="active"></div>
        </div>
        <div class="stepbutton">
        <button type="button" class="lprevbtn3">previous</button>
                <button type="submit" class="lsubmitbtn1">Submit</button>
        </div>
    </div>
    </div>
   

</div>