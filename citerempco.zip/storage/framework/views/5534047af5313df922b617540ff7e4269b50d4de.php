<div class="dots" id="loanapplicationdots">
    <div class="dot dot1 activates"></div>
    <div class="dot dot2"></div>
    <div class="dot dot3"></div>
    <div class="dot dot4"></div>
</div><?php /**PATH D:\citerempco\resources\views/fix/loandot.blade.php ENDPATH**/ ?>