<div class="loanapplication text-lg ">
    <div class="form-outside">

        <form action="<?php echo e(route('citerempco.loanappllication.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h2 class="text-center text-2xl">Loan Application</h2>
            <div class="holder page-slide" id="holder">



                <?php echo $__env->make('form.step1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('form.step2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('form.step3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('form.step4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            </div>
        </form>
    </div>
</div>
<script src="<?php echo e(asset('js/loanapplication.js')); ?>"> </script>
<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function(){
    swal("Friendly Reminders", "Make sure to fill in all fields before submitting your information for proper registration", "info",{
        button:{
            text:"Let's Go"
        }
    })
});
</script>
<?php $__env->stopSection(); ?><?php /**PATH D:\citerempco\resources\views/form/loanapplicationform.blade.php ENDPATH**/ ?>