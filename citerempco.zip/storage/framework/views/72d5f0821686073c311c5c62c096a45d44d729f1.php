

<?php $__env->startSection('content'); ?>
<div class="applicationform">
    <?php echo $__env->make('fix.profilesection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="applicationform-content">

    <div class="applicationformforadds">
        <?php echo $__env->make('applicationformforadds.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.custome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\citerempco\resources\views/applicationformforadds/index.blade.php ENDPATH**/ ?>