

<?php $__env->startSection('content'); ?>
<div class="applicationform">
    <?php echo $__env->make('fix.profilesection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="applicationform-content">

        <div class="certification">

            <h1>Certification</h1>

            <div class="cetificate-input">  
                <div>
                    <p>This is to certify that <input type="text" class="cinput1"> has a total deduction of <input type="text" class="cinput2">(Please see attached Authorized payroll / payslip for itemized deduction ) and a net take home pay of <input type="text" class="cinput3"> in which sufficient for the payment of his/her monthly loan ammortization.</p>
                </div>
            </div>

            <div class="hisbest">
                his / her best this <input type="date" class="cinput4">
            </div>

            <div class="manager-signature">

                <div>
                    <p>MARCELA M. LAGUMEN</p>
                    <div class="line-manager">
                        Manager
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.custome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\citerempco\resources\views/certification/index.blade.php ENDPATH**/ ?>