    <!-- 
|--------------------------------------------------------------------------
| header
|--------------------------------------------------------------------------
| -->
<header>
        <div class="box">
            <div class="logo-image"><img src="<?php echo e(asset('storage/project_mages/king.ico')); ?>" alt="logo"></div>
            <div class="logoname"> <span>CITEREMPCO</span> <small>Isulan</small></div>
        </div>
        <div class="box">

            <ul>
                <li><a href="<?php echo e(route('citerempco.register')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('citerempco.aboutus')); ?>">About</a></li>
                        <?php if(Auth::check()): ?>
                <li><a href="#">
                        <div><i class="fas fa-envelope"></div></i>
                    </a></li>
                <li><a href="#">
                        <div class="bell"><i class="fas fa-bell"></i> <span id="number">5</span></div>
                    </a></li>
                <li><a href="<?php echo e(route('logout')); ?>">Logouts</a></li>
                
                <?php else: ?>
                <li><a href="<?php echo e(route('login')); ?>">Log-in</a></li>

                <?php endif; ?>



            </ul>
        </div>
    </header>
<?php /**PATH D:\citerempco\resources\views/fixelement/header.blade.php ENDPATH**/ ?>