<div class="loanapplication text-lg ">
    <div class="form-outside">

        <form action="<?php echo e(route('citerempco.loanappllication.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <h2 class="text-center text-2xl">Loan Application</h2>
            <div class="holder page-slide" id="holder">


                <!-- step 2 -->
                <div class="step1">

                    <div class="group1 flex justify-around mt-2">
                        <div class="text-center">
                            <span class="block text-center font-bold">Application For</span>
                            <select name="step1[applicationfor]" id="" class="mt-1">
                                <option value="default">Type of loan</option>
                                <option value="busineness">Business loan</option>
                                <option value="starting">Starting loan</option>
                            </select>
                        </div>

                        <div>
                            <span class="block text-center font-bold">Type of Loan</span>
                            <div class="checkbox-wrapper mt-1">
                                <label class="checkbox-container">New
                                    <input type="checkbox" checked="checked" value="new" name="step1[typeofloan]">
                                    <span class="checkmark"></span>
                                </label>

                                <label class="checkbox-container">Renewal
                                    <input type="checkbox" value="renewal" name="step1[typeofloan]">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="group2 mt-0">
                        <div class="applicant p-2">
                            <p class="font-bold">Applicant</p>
                            <div class="inputs flex">
                                <div class="inputs w-full">
                                    <div class="flex-gow-1 flex items-center justify-center  ">
                                        <span class="block pr-0 ">First Name</span><input type="text"
                                            class="form-control ins" placeholder="First Name" name="step1[applicant][firstname]" id="applicant_firstname">
                                    </div>
                                    <div class="flex-gow-1 flex items-center justify-center ">
                                        <span class="block pr-0 ">Middle Name</span><input type="text"
                                            class="form-control ins" placeholder="Middle Name" name="step1[applicant][middlename]" id="applicant_middlename">
                                    </div>
                                    <div class="flex-gow-1 flex items-center justify-center">
                                        <span class="block pr-0 ">Family Name</span><input type="text"
                                            class="form-control ins" placeholder="Family Name"  name="step1[applicant][familyname]" id="applicant_familyname">
                                    </div>
                                </div>
                                <div class="dateapplied flex flex-col p-2 justify-start items-center w-full">
                                    <div class="flex">
                                        <span class="block ">Date Applied</span><input type="date"
                                            class="form-control ins" name="step1[applicant][dateapplied]" id="applicant_dateapplied">
                                    </div>
                                    <div class="mt-2 flex appliedage">
                                        <span class="inline-block ">Age</span> <input type="text"
                                            class="form-control appliedage ins" name="step1[applicant][age]" id="applicant_age">
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="spouse p-2">
                            <p class="font-bold">Spouse</p>
                            <div class="inputs flex">
                                <div class="inputs w-full">
                                    <div class="flex-gow-1 flex items-center justify-center  ">
                                        <span class="block pr-0 ">First Name</span><input type="text"
                                            class="form-control ins" placeholder="First Name" name="step1[spouse][firstname]" id="spouse_familyname">
                                    </div>
                                    <div class="flex-gow-1 flex items-center justify-center ">
                                        <span class="block pr-0 ">Middle Name</span><input type="text"
                                            class="form-control ins" placeholder="Middle Name" name="step1[spouse][middename]" id="spouse_middlename">
                                    </div>
                                    <div class="flex-gow-1 flex items-center justify-center ">
                                        <span class="block pr-0 ">Family Name</span><input type="text"
                                            class="form-control ins" placeholder="Family Name" name="step1[spouse][familyname]" id="spouse_familyname">
                                    </div>
                                    <div class="flex-gow-1 flex items-center justify-center ">
                                        <span class="block pr-0 ">Occupation</span><input type="text"
                                            class="form-control ins" placeholder="Occupation" name="step1[spouse][occupation]" id="spouse_occupation">
                                    </div>
                                </div>


                                <div class="dateapplied flex flex-col p-2 justify-start items-center w-full">
                                    
                                    <div class="mt-2 flex appliedage">
                                        <span class="inline-block ">Age</span> <input type="text"
                                            class="form-control appliedage ins" name="step1[spouse][age]" id="spouse_age">
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="group3 p-2">

                            <div class=" ">
                                <span class="block font-bold mb-0">Office Address </span><input type="text"
                                    class="form-control ins" placeholder="Occopation" name="step1[officaddress]" id="step1_officeaddress">
                            </div>
                            <div class="flex">
                                <div class="w-full flex items-center">
                                    <span class="block p-1 mr-1">City/Province:</span> <input type="text"
                                        class="form-control ins" name="step1[cityprovince]" id="step1_cityprovince">
                                </div>
                                <div class="w-full flex items-center justify-center">
                                    <span class="inline-block p-1">State</span> <select name="step1[state]" id="step1_state">
                                        <option value="">Choose State</option>
                                        <option value="Philippines">Philippines</option>
                                    </select>
                                </div>
                            </div>


                        </div>
                        <div class="btns">

                            <div class="dots">
                                <div class="activates"></div>
                                <div class=""></div>
                                <div class=""></div>
                                <div class=""></div>
                            </div>
                            <div>
                                <button type="button" class="btn btn-default next1">Next</button>
                            </div>
                        </div>
                    </div>



                </div>

                <!-- step 2 -->

                <div class="step2 p-2">
                    <div class="step2-group1 mt-4">
                        <div class="flex w-full justify-around">
                            <div class="w-full">
                                <span class="block text-left">Savings Deposit</span><input type="text"
                                    class="form-control ins ins21" name="step2[savingdeposit]" id="step2_savinddeposit">
                            </div>
                            <div class="w-full ">
                                <span>Capital Build Up:</span><input type="text" class="form-control ins ins22" name="step2[capitalbuildup]" id="step2_capitalbuildup">
                            </div>
                        </div>
                        <div class="flex w-full md:min-width-1/4 justify-around">

                            <div class="w-full mt-2">
                                <span>I hereby apply for a loan </span><input type="text"
                                    class="form-control ins ins21" name="step2[applyloanfor]" id="step2_applyloanfor">
                            </div>
                            <div class="w-full mt-2">
                                <span>Amout</span><input type="text" class="form-control ins ins22" name="step2[amount]">
                            </div>
                        </div>
                        <div class="mt-2">
                            <span>Period of </span>
                            <div class="flex items-center">
                                <input type="text" class="form-control ins ins21" name="step2[periodof]" id="step2_periodof"><span class="ml-2">days at the rate of
                                    1.25% per month.</span>
                            </div>
                        </div>

                        <div class="flex items-center purposeofloan mt-2">
                            <span class="block">Purpose of Loan:</span> <input type="text"
                                class="form-control ins ins23" name="step2[purposeofloan]">
                        </div>
                        <div class="flex items-center amount mt-2">
                            <span class="block">Amount Applied</span><input type="text" class="form-control ins ins24" name="step2[amountapplied]">
                        </div>
                    </div>

                    <div class="step2-group2 mt-3">

                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Source of Income</th>
                                    <th>Gross Income</th>
                                    <th>Monthly Expenses</th>
                                    <th>Net Income</th>
                                </tr>
                            </thead>
                            <tr>
                                <td>Source of Income</td>
                                <td>Gross Income</td>
                                <td>Monthly Expenses</td>
                                <td>Net Income</td>
                            </tr>
                        </table>
                    </div>
                    <div class="btns">
                        <div class="dots">
                            <div class="activates"></div>
                            <div class="activates"></div>
                            <div class=""></div>
                            <div class=""></div>
                        </div>
                        <div>
                            <button type="button" class="btn btn-default prev1">Previous</button>
                            <button type="button" class="btn btn-default next2">Next</button>
                        </div>
                    </div>

                </div>

                <!-- step 3 -->
                <div class="step3 p-2">

                    <div class="step3-wrapper">
                        <p>
                            I hereby authorize the CITEREMPCO to obtain such other information as may be required in the
                            connection with the application.</p>
                        <p>
                            I am aware that the use of the proceeds of this loan purpose other than those indicated
                            herein
                            is unlawful. That the statements declared above are true and correct to the best of my
                            knowledge. I also agree that should there be any misinterpretation discovered, CITEREMPCO
                            may
                            cause the outright disapproval of this loan application and if the loan has already been
                            granted, CITEREMPCO, may immediately declare the loan due and demandable.
                        </p>
                        <div class="terms">
                            <select name="step3[terms]" id="step3_terms">
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                            <span> Click Yes if Agree to the Term of Contract</span>
                        </div>
                    </div>
                    <div class="btns">
                        <div class="dots">
                            <div class="activates"></div>
                            <div class="activates"></div>
                            <div class="activates"></div>
                            <div class=""></div>
                        </div>
                        <div>
                            <button type="button" class="btn btn-default prev2">Previous</button>
                            <button type="button" class="btn btn-default next3">Next</button>
                        </div>
                    </div>

                </div>

                <!-- step 4 -->

                <div class="step4 p2">
                    <div class="step4-wrapper">

                        <p>
                            For value received, I promised to pay the CENTRAL ISULAN TEACHERS, EMPLOYEES AND RETIREES
                            MULTI
                            -
                            PURPOSE COOPERATIVE or order the sum of <input type="text" name="step4[sumof]" id="step4_sumof"
                                class="form-control ins stp4in1">
                            pesos<input type="text" name="step4[pesos]" id="step4_pesos" class="form-control ins stp4in2"> payable <input
                                type="text" name="step4[payable]" id="step4_payable" class="form-control  ins stp4in3">in installment of <input
                                type="text" name="step4[installment]" id="step4_installment" class="form-control">
                            pesos<input type="text" name="step4[installmentpesos]" id="step4_installmentpesos" class="form-control ins stp4in4"> monthly until the
                            full
                            amount has been paid.</p>
                        <p>

                            In case dafault in payments as here in agreed, the entire balance of this note shall become
                            immediately
                            due to the payable at the option of the cooperative

                        </p>
                    </div>
                    <div class="btns">
                        <div class="dots">
                            <div class="activates"></div>
                            <div class="activates"></div>
                            <div class="activates"></div>
                            <div class="activates"></div>
                        </div>
                        <div>

                            <button type="button" class="btn btn-default prev3">Previous</button>
                            <button type="submit" class="btn btn-default submit1">Submit</button>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
</div>

<script>
const slidePage = document.querySelector(".page-slide");
const loancontainer = document.querySelector(".loanapplication");
const next1btn = document.querySelector(".next1");
const next2btn = document.querySelector(".next2");
const next3btn = document.querySelector(".next3");

const prev1btn = document.querySelector(".prev1");
const prev2btn = document.querySelector(".prev2");
const prev3btn = document.querySelector(".prev3");
const submitbtn = document.querySelector(".submit1");

next1btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "-100%";
    loancontainer.style.height = "600px";
    activateClass(2);
});
next2btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "-200%";
    loancontainer.style.height = "500px";
});
next3btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "-300%";
    loancontainer.style.height = "400px";
});


prev1btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "0";
    loancontainer.style.height = "650px";
});
prev2btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "-100%";
    loancontainer.style.height = "600px";
});
prev3btn.addEventListener("click", function() {
    slidePage.style.marginLeft = "-200%";
    loancontainer.style.height = "500px";
});


let dots = document.querySelectorAll(".dots .dot");

function activateClass(e) {
    dots[e].classList.add("activates");
}
</script><?php /**PATH D:\citerempco\resources\views/form/applicationform.blade.php ENDPATH**/ ?>