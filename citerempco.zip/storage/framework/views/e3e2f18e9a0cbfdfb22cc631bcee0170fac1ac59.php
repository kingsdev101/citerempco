<div class="estep1">


    <section class="einput">

        <p class="ap">Applicant:</p>
        <div class="group-box">
            <div class="eboxes eb1">
                <div class="ediv">
                    <p>First Name:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>
                <div class="ediv">
                    <p>Middle Name:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>
                <div class="ediv">
                    <p>Family Name:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>
                <div class="ediv ">
                    <p>School Address: </p>
                    <div class="edc">
                        <input type="text" class="eis" autocomplete="off">
                        <input type="text" placeholder="city" class="ecty mx-2" autocomplete="off">
                        <select name="" id="">
                            <option value="">State</option>
                        </select>

                    </div>
                </div>
                <div class="ediv">
                    <p>Purpose of Loans:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>


            </div>

            <div class="eboxes eb2 pl-3">
                <div class="ediv">
                    <p>Date:</p>
                    <div><input type="date" class="ein" autocomplete="off"></div>
                </div>
                <div class="ediv">
                    <p>Application No:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>
                <div class="ediv">
                    <p>Amount Loan Granted:</p>
                    <div><input type="text" class="ein" autocomplete="off"></div>
                </div>

            </div>



        </div>
        <div class="einfo">
            <div class="circle-wrapper">
                <div class="active"></div>
                <div></div>

            </div>
            <div class="stepbutton">
                <button type="button" class="enextbtn1">next</button>
            </div>
        </div>
    </section>
</div><?php /**PATH D:\citerempco\resources\views/emergenyloan/step1.blade.php ENDPATH**/ ?>