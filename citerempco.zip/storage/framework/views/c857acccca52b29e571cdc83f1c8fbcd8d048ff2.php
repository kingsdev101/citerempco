

<?php $__env->startSection('content'); ?>
<div class="applicationform">
    <?php echo $__env->make('fix.profilesection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="applicationform-content">

        <div class="emergencyloan">
            <div class="ebundel">

                <div class="eform-wrapper">
                    <form action="">
                        <h1>Emergency Loan Application / Agreement</h1>
                        <div class="eholder" id="eholder">
                            
                                <?php echo $__env->make('emergenyloan.step1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('emergenyloan.step2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('emergenyloan.step3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                
                        </div>
        
        
                    </form>
                </div>
            </div>
        
        </div>



    </div>
</div>
</div>

<script>
const eform= document.querySelector(".eform-wrapper");
const emergency_step_holder = document.querySelector(".eholder");
const enextbtn1 = document.querySelector(".enextbtn1");
const enextbtn2 = document.querySelector(".enextbtn2");

const eprevbtn1 = document.querySelector(".eprevbtn1");
const eprevbtn2 = document.querySelector(".eprevbtn2");



enextbtn1.addEventListener("click", function() {
    emergency_step_holder.style.marginLeft = "-100%";
    eform.style.height = "650px";
});
enextbtn2.addEventListener("click", function() {
    emergency_step_holder.style.marginLeft = "-200%";
    eform.style.height = "100%";
});


eprevbtn1.addEventListener("click", function() {
    emergency_step_holder.style.marginLeft = "0";
    eform.style.height = "600px";
});
eprevbtn2.addEventListener("click", function() {
    emergency_step_holder.style.marginLeft = "-100%";
    eform.style.height = "650px";
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.custome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\citerempco\resources\views/emergenyloan/index.blade.php ENDPATH**/ ?>