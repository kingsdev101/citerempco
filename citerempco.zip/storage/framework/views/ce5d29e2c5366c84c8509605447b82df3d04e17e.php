<section class="profile-section">
    <div class="profileimage">
        <div class="image">
            <img src="<?php echo e(asset('storage/project_mages/user.png')); ?>" alt="user">
        </div>
        <div class="">
            <p>John Ross B. Mariñas</p>
            <span>Member</span>
        </div>
    </div>

    <div class="requirements">
        Requirements
    </div>

    <div class="menu-list">
        <ul>

            <li> <a href="<?php echo e(route('citerempco.loanapplication.form')); ?>">Application Form</a></li>
            <li><a href="<?php echo e(route('citerempco.deedofassigment.index')); ?>"> Deed of Assignment</a></li>
            <li> <a href="<?php echo e(route('citerempco.promissory.index')); ?>"> Promissory Note</a></li>
            <li><a href="<?php echo e(route('citerempco.credit.index')); ?>"> Application for Credit</a></li>
            <li><a href="<?php echo e(route('citerempco.certication.index')); ?>"> Certification </a></li>
            <li><a href="<?php echo e(route('citerempco.creditlifeinsurance.index')); ?>"> Credit Life Insurance</a></li>
            <li><a href="<?php echo e(route('citerempco.emergencyloan.index')); ?>"> Emergency Loan</a></li>
            <li><a href="<?php echo e(route('citerempco.applicationfadds.index')); ?>"> Application Form for ADDS</a></li>
            <li><a href="<?php echo e(route('citerempco.loanagreement.index')); ?>">Loan Application Agreement</a></li>
        </ul>
    </div>

</section><?php /**PATH D:\citerempco\resources\views/fix/profilesection.blade.php ENDPATH**/ ?>